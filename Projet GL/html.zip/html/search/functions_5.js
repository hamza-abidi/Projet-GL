var searchData=
[
  ['getsize',['getSize',['../class_manage_file.html#abc31b87fa59ce977343415c6f31aed91',1,'ManageFile']]]
];
