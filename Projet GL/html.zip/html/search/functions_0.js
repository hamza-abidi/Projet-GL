var searchData=
[
  ['activertermcolor',['activerTermcolor',['../class_colors.html#a22ceb07f137ca41c5772af5515337659',1,'Colors']]]
];
