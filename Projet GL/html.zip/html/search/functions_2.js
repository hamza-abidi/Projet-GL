var searchData=
[
  ['close',['close',['../class_manage_file.html#a8eb66054851cb3752ded544b001df4f0',1,'ManageFile']]],
  ['colors',['Colors',['../class_colors.html#a65bde56fe97e9357aa8a901c0144eab5',1,'Colors']]]
];
