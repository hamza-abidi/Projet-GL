var searchData=
[
  ['begin',['begin',['../class_manage_file.html#ac779e525496629ade46b98614d81e232',1,'ManageFile']]]
];
