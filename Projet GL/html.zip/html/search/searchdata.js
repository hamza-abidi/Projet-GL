var indexSectionsWithContent =
{
  0: "abcdegmrsw~",
  1: "cm",
  2: "m",
  3: "abcdegmrsw~"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Structures de données",
  2: "Fichiers",
  3: "Fonctions"
};

