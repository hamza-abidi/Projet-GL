var class_map =
[
    [ "Map", "class_map.html#ab92768fc2db576bf956f443190b58d90", null ],
    [ "display", "class_map.html#ad5fa4af56ebdcfdbfe999ae4ba971135", null ],
    [ "modify", "class_map.html#a922cd70b6032ae3a6a2df04b39398e8e", null ]
];