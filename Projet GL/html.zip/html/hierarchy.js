var hierarchy =
[
    [ "Colors", "class_colors.html", [
      [ "Map", "class_map.html", null ]
    ] ],
    [ "ManageFile", "class_manage_file.html", null ]
];