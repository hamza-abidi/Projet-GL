var NAVTREE =
[
  [ "GL projet", "index.html", [
    [ "Structures de données", "annotated.html", [
      [ "Structures de données", "annotated.html", "annotated_dup" ],
      [ "Index des structures de données", "classes.html", null ],
      [ "Hiérarchie des classes", "hierarchy.html", "hierarchy" ],
      [ "Champs de donnée", "functions.html", [
        [ "Tout", "functions.html", null ],
        [ "Fonctions", "functions_func.html", null ]
      ] ]
    ] ],
    [ "Fichiers", null, [
      [ "Liste des fichiers", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_colors_8h_source.html"
];

var SYNCONMSG = 'cliquez pour désactiver la synchronisation du panel';
var SYNCOFFMSG = 'cliquez pour activer la synchronisation du panel';