var _manage_file_8cpp =
[
    [ "map_directory", "_manage_file_8cpp.html#ac1a54bf5b405091b796e40b5fe91d933", null ]
];