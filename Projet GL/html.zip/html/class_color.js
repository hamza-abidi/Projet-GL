var class_color =
[
    [ "activerTermcolor", "class_color.html#a024a64972cecb3851790840d0101e485", null ],
    [ "desactiverTermcolor", "class_color.html#a9b6dce5671d9ebb5258da42d34aba6d7", null ],
    [ "displayColor", "class_color.html#a7a59cffa33fa8b850c07dd6272f7b228", null ],
    [ "displayColor", "class_color.html#af3e68470d1bbb7322b313d8621e16af1", null ]
];