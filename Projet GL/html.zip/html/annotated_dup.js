var annotated_dup =
[
    [ "Colors", "class_colors.html", "class_colors" ],
    [ "ManageFile", "class_manage_file.html", "class_manage_file" ],
    [ "Map", "class_map.html", "class_map" ]
];