var class_colors =
[
    [ "Colors", "class_colors.html#a65bde56fe97e9357aa8a901c0144eab5", null ],
    [ "activerTermcolor", "class_colors.html#a22ceb07f137ca41c5772af5515337659", null ],
    [ "desactiverTermcolor", "class_colors.html#a7de6133476d73eaba1973184225c0641", null ],
    [ "displayColor", "class_colors.html#ad28ab0599862a1abf71d49afa2386cdd", null ],
    [ "displayColor", "class_colors.html#a8a346bc73359978fda0a1f07c436a6f2", null ]
];